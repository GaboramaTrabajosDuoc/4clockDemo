// src/config/anonUser.ts

export const ANON_USER_ID = '8d12c89f-12e4-4d8f-9d0f-2c75dfcd1234'; // copia el UUID real de Supabase
