//TODO after creating task.d.ts, ensure all references to Task type are updated
//the porpose of the type folder is to define types used across the app